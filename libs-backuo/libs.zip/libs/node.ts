export type Node = {
  move?: string
  suffix?: string
  nags: string[]
  comment?: string
  variations: Node[]
}
