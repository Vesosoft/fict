node --inspect-brk node_modules/.bin/vitest --run
